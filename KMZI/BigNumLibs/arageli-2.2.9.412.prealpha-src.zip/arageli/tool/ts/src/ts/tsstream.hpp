/* /////////////////////////////////////////////////////////////////////////////
//
//  File:       tsstream.hpp
//  Created:    2005/11/8    23:52
//
*/

#ifndef __tsstream_hpp__
#define __tsstream_hpp__

#include "config.hpp"
#include <sstream>

extern TS_DECL std::ostringstream tout;

#endif /*__tsstream_hpp__*/
/* End of file tsstream.hpp */
