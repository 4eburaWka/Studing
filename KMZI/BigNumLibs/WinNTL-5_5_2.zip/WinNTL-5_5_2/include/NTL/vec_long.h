
#ifndef NTL_vec_long__H
#define NTL_vec_long__H

#include <NTL/vector.h>

NTL_OPEN_NNS

NTL_vector_decl(long,vec_long)

NTL_io_vector_decl(long,vec_long)

NTL_eq_vector_decl(long,vec_long)

NTL_CLOSE_NNS

#endif
