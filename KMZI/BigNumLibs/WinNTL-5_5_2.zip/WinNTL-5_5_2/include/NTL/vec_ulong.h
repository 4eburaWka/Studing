
#ifndef NTL_vec_ulong__H
#define NTL_vec_ulong__H

#include <NTL/vector.h>

NTL_OPEN_NNS

NTL_vector_decl(_ntl_ulong,vec_ulong)

NTL_io_vector_decl(_ntl_ulong,vec_ulong)

NTL_eq_vector_decl(_ntl_ulong,vec_ulong)

NTL_CLOSE_NNS

#endif
