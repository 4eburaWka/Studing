
#ifndef NTL_vec_vec_ZZ__H
#define NTL_vec_vec_ZZ__H

#include <NTL/vec_ZZ.h>

NTL_OPEN_NNS

NTL_vector_decl(vec_ZZ,vec_vec_ZZ)

NTL_eq_vector_decl(vec_ZZ,vec_vec_ZZ)

NTL_io_vector_decl(vec_ZZ,vec_vec_ZZ)

NTL_CLOSE_NNS

#endif
