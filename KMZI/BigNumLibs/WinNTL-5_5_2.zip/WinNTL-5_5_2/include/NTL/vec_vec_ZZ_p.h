
#ifndef NTL_vec_vec_ZZ_p__H
#define NTL_vec_vec_ZZ_p__H

#include <NTL/vec_ZZ_p.h>

NTL_OPEN_NNS

NTL_vector_decl(vec_ZZ_p,vec_vec_ZZ_p)

NTL_eq_vector_decl(vec_ZZ_p,vec_vec_ZZ_p)

NTL_io_vector_decl(vec_ZZ_p,vec_vec_ZZ_p)

NTL_CLOSE_NNS

#endif
