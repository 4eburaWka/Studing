echo 'zdarova'>text.txt
ln text.txt hard_link
ln -s text.txt symb_link
ls -i
