cd
touch file1.txt file2.txt file3.txt file4.txt
chmod 700 file1.txt
chmod 647 file2.txt
chmod 304 file3.txt
chmod 272 file4.txt
ls -l

