cd
chmod 06 file1.txt
chmod 33 file2.txt 
chmod 203 file3.txt
ls -l
