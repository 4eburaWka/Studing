cd /
ls -l

ls -l /etc
ls -l /bin
ls -l /dev
ls -l /root

cd /etc
ls -l shadow passwd
cat shadow
cat passwd
