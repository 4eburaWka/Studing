cd
chmod go-rwx file1.txt
chmod u=rw,g=r,o=rwx file2.txt
chmod u=wx,o=r file3.txt
chmod uo=w,g=rwx file4.txt
ls -l
