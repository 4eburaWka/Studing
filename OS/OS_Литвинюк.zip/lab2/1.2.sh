cd Folder
echo 'Zdarova'>text.txt
ln -s text.txt link
cat link
rm text.txt
cat link
mkdir dir
ln -s dir dir_link
