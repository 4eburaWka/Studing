cd Folder
echo 'Zdarova'>text.txt
ln text.txt link
rm text.txt
cat link
mkdir dir
ln dir linkToDir

