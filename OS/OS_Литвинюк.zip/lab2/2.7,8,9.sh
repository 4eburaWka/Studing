cd
chmod 222 file1.txt
ls -l

cp -bin-ls 
chmod -x ls
./ls

cd /root
