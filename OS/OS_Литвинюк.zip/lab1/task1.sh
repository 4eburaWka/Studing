pwd
mkdir dir1 dir2
ls
ls dir1
cd /
ls
cd /media/timofei/Files/Studing/OS/lab1
rmdir dir1 dir2
man ls
man cd
whatis ls
apropos ls
info ls
