//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by task1.rc
//
#define IDC_MYICON                      2
#define IDD_TASK1_DIALOG                102
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDS_HELLO                       106
#define IDI_TASK1                       107
#define IDI_SMALL                       108
#define IDC_TASK1                       109
#define IDR_MAINFRAME                   128
#define IDR_TOOLBAR2                    131
#define IDB_BITMAP2                     150
#define IDI_ICON1                       151
#define IDC_CURSOR1                     152
#define IDD_DIALOG1                     154
#define ID__1                           32771
#define ID__2                           32772
#define ID__3                           32775
#define ID__4                           32776
#define ID_BUTTON32777                  32777
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        155
#define _APS_NEXT_COMMAND_VALUE         32778
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
