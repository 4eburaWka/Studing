disp(fminbnd('func6_1',0.5,1.0))
fplot(@func6_1,[0,3])
disp(fminsearch(@func6_2,[1,1]));