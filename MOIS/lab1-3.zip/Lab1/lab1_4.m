fzero('Myfunc',pi/2)
fzero('Myfunc',pi/2,optimset('TolX',1e-4))
fplot(@Myfunc,[0,pi/2])