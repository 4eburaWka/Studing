function y = Myfunc(x)
y = cos(x) - x;
end


