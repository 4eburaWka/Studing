r=roots([1 -3 3 -3 2]);
disp(r);