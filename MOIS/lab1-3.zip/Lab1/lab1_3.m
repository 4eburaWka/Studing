N = [4 12 -1 1;
    2 1 -5 -1;
    1 -1 10 2;
    -4 6 11 -1;
    ];
L = [32;10;22;17];
R = N\L;
disp(R)
plot(R,sin(R),"--");
hold on;
plot(R,cos(R),":");