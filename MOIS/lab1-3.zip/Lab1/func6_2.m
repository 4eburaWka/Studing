function y = func6_2(x)
y=x(1)^2 + x(2)^2;
end

