%lab2_3
[x,y]=ode45(@diffunc23,[0 3000],[2;0]);
plot(x,y(:,1))