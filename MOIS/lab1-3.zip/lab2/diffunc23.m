function dydt=diffunc23(x,y)
dydt=[y(2);-y(1)+1000*(1-y(1)^2)*y(2)];
end