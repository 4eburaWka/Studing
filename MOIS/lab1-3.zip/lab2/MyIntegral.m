function y = MyIntegral(a)
i=input('Выберите способ: 1. Метод трапеций, 2. Метод Симпсона: ','s');
func=@(x)sin(x).*exp(-x);
switch i
    case '1'
    y_previos=0;
    di=0.1;
    while di>0.00001
        X=0:di:5;
        y=trapz(X,func(X));
        if abs(y_previos-y)>di
            y_previos=y;
            di= di/10;
        else 
            break
        end
    end
    case '2'
    y= quad(func,0,5);
    otherwise
        disp('Incorrect Number')
        y=0;
end
end