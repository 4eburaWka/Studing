function dydt=diffunc2(x,y)
dydt=[0.01*x^2+y(2);-y(1)];
end