function rebuild(src,event)
global hAxes hE1 hE2 hE3 hT1 hT2 hT3 hB hB2
        cla(hAxes)
        set(hAxes,'Position', [20 40 250 300])
        set(hE1,'Visible','on')
        set(hT1,'Visible','on')
        set(hE2,'Visible','on')
        set(hT2,'Visible','on')
        set(hE3,'Visible','on')
        set(hT3,'Visible','on')
        set(hB,'Visible','on')
        set(hB2,'Visible','off')
    end