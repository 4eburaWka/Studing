function DiffBegin(src,entry)
    global hAxes hE1 hE2 hE3 hE4 hE5
    x1 = str2double(get(hE1,'String'));
    x2 = str2double(get(hE2,'String'));
    y1 = str2double(get(hE3,'String'));
    y2 = str2double(get(hE4,'String'));
    k = str2double(get(hE5,'String'));
    cla(hAxes)
    [x,y]=ode15s(@(x,y)[y2;-y1+k*(1-y1^2)*y2],[x1 x2],[y1,y2]);
    disp(y(:,1))
    disp(x)
    plot(hAxes,x,y(:,1))
    hold on
    plot(hAxes,x,y(:,2))
    hold off
end