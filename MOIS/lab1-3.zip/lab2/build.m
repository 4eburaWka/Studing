function build(src,event)
    m=menu('Какая функция ?','sin x','cos x','tg x','ctg x','exp x');
    global hAxes hE1 hE2 hE3
    cla(hAxes)
    x=str2double(get(hE1,'String')):str2double(get(hE2,'String')):str2double(get(hE3,'String'));
    switch m
        case 1
            plot(hAxes,x,sin(x))
        case 2
            plot(hAxes,x,cos(x))
        case 3
            plot(hAxes,x,tan(x))
        case 4
            plot(hAxes,x,cotd(x))
        case 5
            plot(hAxes,x,exp(x))
        otherwise
            b=0:0.25:10;
            plot(b,cosh(b))
    end