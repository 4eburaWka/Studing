hFig= figure("Position",[550 400 600 500]);
global hAxes hE1 hE2 hE3 hT1 hT2 hT3 hB 
hAxes = axes('Units', 'points', 'Position', [20 40 250 300], 'FontSize',6);
hT1=uicontrol('Style','text','Position', [400 430 100 20],'String','Левая граница');
hE1=uicontrol('Style','edit','Position', [400 410 100 20]);
hT2=uicontrol('Style','text','Position', [400 390 100 20],'String','Приращение');
hE2=uicontrol('Style','edit','Position', [400 370 100 20]);
hT3=uicontrol('Style','text','Position', [400 350 100 20],'String','Правая граница');
hE3=uicontrol('Style','edit','Position', [400 330 100 20]);
hB =uicontrol('Style','pushbutton','Position', [400 270 100 30],'String','Построить','Callback','buildanim');