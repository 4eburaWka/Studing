m=menu('Выберите вариант:','K=0','K=0.01');
global k;
if m==2
disp('K=0.01')
k=0.01;
[x,y]=ode45(@diffunc,[0 20],[0;1]);
 plot(x,y(:,1),x,y(:,2))
else
disp('K=0')
k=0;
[x,y]=ode45(@diffunc,[0 20],[0;1]);
plot(x,y(:,1),x,y(:,2))
end
  