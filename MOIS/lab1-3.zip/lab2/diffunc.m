function dydt=diffunc(x,y)
global k;
dydt=[k*x^2+y(2);-y(1)];
end