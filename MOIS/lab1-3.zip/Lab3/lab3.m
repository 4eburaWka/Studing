%•	малое (10-25сек.) = 1; 
%•	среднее(20-40сек.) = 2; 
%•	большое(35-50сек.) = 3.
% 1 цикл = 60 сек.
timeSvetofor=randi([10,35]);
statusTimeSvetofor=0;
%•	очень малое (0-18) = 1; 
%•	малое (16-36) = 2; 
%•	среднее (34-56)= 3; 
%•	большое (54-76) = 4; 
%•	очень большое (72-90)= 5.
countNS=0;
countWE=0;
coefNS=[];
coefWE=[];
statusNS=0;
statusWE=0;
%•	увеличить (0-20сек.) = 1; 
%•	не изменять (-15-15сек.) = 2;
%•	уменьшить (-20-0сек.) = 3.
svetoforStatus=0;

for i=1:10
    disp(i)
    disp(["Время зеленого светофора на СЮ: ",timeSvetofor])
    disp(["Время зеленого светофора на ЗВ: ",(60-timeSvetofor)])
    statusWE=0;
    statusNS=0;
    statusTimeSvetofor=0;
    countNS=max([countNS + randi([5,15],1,1) - round(timeSvetofor/3),0]);
    countWE=max([countWE + randi([5,15],1,1) - round((60-timeSvetofor)/3),0]);
    disp(["countNS: ",countNS])
    disp(["countWS: ",countWE])
    [~,statusTimeSvetofor]=max([TrapezFunc(0,10,20,25,timeSvetofor),TrapezFunc(20,25,35,40,timeSvetofor), TrapezFunc(35,40,50,60,timeSvetofor)]);
    [~,statusNS]=max([TrapezFunc(-100,0,12,18,countNS),TrapezFunc(16,22,32,36,countNS), ...
        TrapezFunc(34,40,50,56,countNS),TrapezFunc(54,60,70,76,countNS),TrapezFunc(72,78,90,1000,countNS)]);
    [~,statusWE]=max([TrapezFunc(-100,0,12,18,countWE),TrapezFunc(16,22,32,36,countWE), ...
        TrapezFunc(34,40,50,56,countWE),TrapezFunc(54,60,70,76,countWE),TrapezFunc(72,78,90,1000,countWE)]);
        disp([TrapezFunc(0,10,20,25,timeSvetofor),TrapezFunc(20,25,35,40,timeSvetofor), TrapezFunc(35,40,50,60,timeSvetofor)])
    disp([TrapezFunc(-100,0,12,18,countNS),TrapezFunc(16,22,32,36,countNS), ...
        TrapezFunc(34,40,50,56,countNS),TrapezFunc(54,60,70,76,countNS),TrapezFunc(72,78,90,1000,countNS)])
    disp([TrapezFunc(-100,0,12,18,countWE),TrapezFunc(16,22,32,36,countWE), ...
        TrapezFunc(34,40,50,56,countWE),TrapezFunc(54,60,70,76,countWE),TrapezFunc(72,78,90,1000,countWE)])
    svetoforStatus=WhatToDo(statusTimeSvetofor,statusNS,statusWE);
disp(["states: ",statusTimeSvetofor,statusNS,statusWE,svetoforStatus])
    
    switch svetoforStatus
        case 1
            disp('увеличить (0-20сек.)')
            timeSvetofor=min([timeSvetofor+randi([0,20],1,1),50]);
        case 2
            disp('не изменять (-15-15сек.)')
            timeSvetofor=max([10,min([timeSvetofor+randi([-15,15],1,1),50])]);
        case 3
            disp('уменьшить (-20-0сек.)')
            timeSvetofor=max([timeSvetofor+randi([-20,0],1,1);10]);
        otherwise
            disp('Anomaly')
    end
end