function k = TrapezFunc(a,b,c,d,x)
k=max([min([(x-a)./(b-a),1,(d-x)./(d-c)]),0]);
end